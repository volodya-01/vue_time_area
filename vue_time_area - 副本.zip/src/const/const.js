const alltime = []
for(let i=0;i<1440;i++){
  alltime.push(0)
}

export default{
    alltime
}